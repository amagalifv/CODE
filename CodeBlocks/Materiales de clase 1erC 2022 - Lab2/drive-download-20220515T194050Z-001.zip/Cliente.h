#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED

#include "Fecha.h"
#include "funciones.h"

using namespace std;

class Cliente{

private: 
    int dniCliente;
    char nombreCliente[20]={0};
    char apellidoCliente[20]={0};
    char emailCliente[30]={0};
    char telefonoCliente[25]={0};
    Fecha fechaNacimiento;
    bool estado;

public:
    ///CONSTRUCTOR CON VALORES POR OMISIÓN
    Cliente(int pDni=0, const char *pNombre="nada", const char *pApellido="nada", const char *pEmail="nada", const char *pTelefono="nada", Fecha pFechaNac=0, bool pEstado=true){
        dniCliente=pDni;
        strcpy(nombreCliente,pNombre);
        strcpy(apellidoCliente,pApellido);
        strcpy(emailCliente,pEmail);
        strcpy(telefonoCliente,pTelefono);
        fechaNacimiento=pFechaNac;
        estado=pEstado;
    }

    ///SETTERS
    void setDni(int pDni){dniCliente=pDni;}
    void setNombre(const char *pNombre){strcpy(nombreCliente,pNombre);}
    void setApellido(const char *pApellido){strcpy(apellidoCliente,pApellido);}
    void setEmail(const char *pEmail){strcpy(emailCliente, pEmail);}
    void setTelefono(const char *pTelefono){strcpy (telefonoCliente, pTelefono);}
    void setFechaNacimiento(Fecha pFecha){fechaNacimiento=pFecha;}
    void setEstado(bool pEstado){estado=pEstado;}

    ///GETTERS
    int getDni(){return dniCliente;}
    const char *getNombre(){return nombreCliente;}
    const char *getApellido(){return apellidoCliente;}
    const char *getEmail(){return emailCliente;}
    const char *getTelefono(){return telefonoCliente;}
    Fecha getFechaNacimiento(){return fechaNacimiento;}
    int getEstado(){return estado;}

    ///METODOS
    void Cargar(int dni=-1);
    void Mostrar();
    int leerDeDisco(int pos);
    int grabarEnDisco(int pos=0);

};

///FUNCIONES DE LA CLASE CLIENTE
void Cliente::Cargar(int dni){
    char auxChar[20]={0};
    int auxInt=0;

    if(dni==0){
        cout<<"DNI:  ";
        cin>>auxInt;
        setDni(auxInt);
    }
    else{
        setDni(dni);

        cout<<"NOMBRE: ";
        cargarCadena(auxChar,20);
        setNombre(auxChar);
        
        cout<<"APELLIDO: ";
        cargarCadena(auxChar,20);
        setApellido(auxChar);

        cout<<"EMAIL: ";
        cargarCadena(auxChar,20);
        setEmail(auxChar);

        cout<<"TELEFONO: ";
        cargarCadena(auxChar,20);
        setTelefono(auxChar);

        fechaNacimiento.CargarNacimiento();

        setEstado(1);

        cout<<endl;
    }
}
void Cliente::Mostrar(){

    cout<<"DNI:  "<<getDni()<<endl;
    cout<<"NOMBRE: "<<getNombre()<<endl;
    cout<<"APELLIDO: "<<getApellido()<<endl;
    cout<<"EMAIL: "<<getEmail()<<endl;
    cout<<"TELEFONO: "<<getTelefono()<<endl;
    cout<<"FECHA DE NACIMIENTO: ";
    fechaNacimiento.Mostrar();
    cout<<"ESTADO: "<<getEstado()<<endl<<endl;
}
int Cliente::leerDeDisco(int pos){
    /******************************************
     Valores que retorna leerDeDisco(int pos):
     -1: NO ENCONTRÓ EL ARCHIVO
      1: LEYO EL ARCHIVO
      2:
    ******************************************/
    FILE *archivo;
    int leyo=-1;

    archivo=fopen("Clientes.dat","rb");

    if(archivo==NULL){
        return -1;
    }

    fseek(archivo, pos*sizeof(Cliente), 0);
    leyo=fread(this, sizeof(Cliente), 1, archivo);

    fclose(archivo);
    return leyo;
}
int Cliente::grabarEnDisco(int pos){
    /******************************************
     Valores que retorna grabarEnDisco(int pos):
     -1: NO PUDO GRABAR EN EL ARCHIVO
      1: ESCRIBIÓ EL ARCHIVO
      2:
    ******************************************/
FILE *archivo;
    int escribio;

    if(pos==-1){
        archivo=fopen("Clientes.dat", "ab");
        if(archivo==NULL){
            return -1;
        }
    }
    else{
        archivo=fopen("Clientes.dat", "rb+");
        if(archivo==NULL){
            return -1;
        }
        fseek(archivo, sizeof(Cliente)*pos, 0);
    }

    escribio=fwrite(this, sizeof(Cliente), 1, archivo);
    fclose(archivo);
    return escribio;
}
///FIN FUNCIONES DE LA CLASE CLIENTE

#endif // CLIENTE_H_INCLUDED
